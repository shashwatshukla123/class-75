import React,{Component} from 'react';
import {Button,View,Text,Image,KeyboardAvoidingView,StyleSheet,TextInput,TouchableOpacity} from 'react-native';
import db from '../config'
import firebase from 'firebase';

export default class LoginScreen extends React.Component{
  constructor(){
    super()
    this.state={
      emailID:'',
      password:'',
    }
  }

  login=async(email,password)=>{
  /*firebase.auth().signInWithEmailAndPassword(emailID, password)
  .then((userCredential) => {
    // Signed in
    this.props.navigation.navigate('Transaction')
    // ...
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
  });
*/
if (email && password){
          try{
            const response = await firebase.auth().signInWithEmailAndPassword(email,password)
            if(response){
              this.props.navigation.navigate('Transaction')
            }
          }
          catch(error){
            switch (error.code) {
              case 'auth/user-not-found':
                alert("user dosen't exists")
                console.log("doesn't exist")
                break
              case 'auth/invalid-email':
                alert('incorrect email or password')
                console.log('invaild')
                break
            }
          }
        }
        else{
            alert('enter email and password');
        }
  }

  render(){
    return(
            <KeyboardAvoidingView behavior="padding" style={styles.container}>
            <View>
              <Image
                source={require("../assets/booklogo.jpg")}
                style={{width:200, height: 200}}/>
              <Text style={{textAlign: 'center', fontSize: 30}}>Wily</Text>
            </View>
            <View>
            <TextInput
            style={styles.inputBox}
            placeholder="abc@xyz.com"
            keyboardType="email-address"
            onChangeText={text=>{
              this.setState({
                emailID:text
              })
            }}
            />

               <TextInput
            style={styles.inputBox}
            placeholder="Password"
            secureTextEntry={true}
            onChangeText={text=>{
              this.setState({
                password:text
              })
            }}
            />
            <View>
            <TouchableOpacity style={styles.submitButton} onPress={()=>{this.login(this.state.emailID,this.state.password)}}>
            <Text style={styles.displayText}>Login</Text>
            </TouchableOpacity>
            </View>

            </View>
            </KeyboardAvoidingView>


    )
  }
}

const styles = StyleSheet.create({
      container: {
      flex: 1,
      justifyContent: 'center',
      alignSelf: 'center',
      alignItems:'center'
    },
    inputBox:{
      width:300,
      height:40,
      margin:10,
      borderWidth:1.5,
      fontSize:'20',
      },
      submitButton:{
      width:100,
      height:30,
      borderWidth:1,
      marginTop:20,
      marginLeft:100,
      backgroundColor:'red'
      },
      displayText:{
        fontSize:20,
        textAlign:'center'
      }

})