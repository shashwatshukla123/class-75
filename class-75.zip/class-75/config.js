import * as firebase from 'firebase'
require('@firebase/firestore')

 var firebaseConfig = {
    apiKey: "AIzaSyCI3HPTWP494B5eTh_OtIFtIU2Jutg0kUY",
    authDomain: "liberary-app-83e0c.firebaseapp.com",
    projectId: "liberary-app-83e0c",
    storageBucket: "liberary-app-83e0c.appspot.com",
    messagingSenderId: "207456343482",
    appId: "1:207456343482:web:a8c3338f0e86b0b7eb7983"
  };  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  export default firebase.firestore();